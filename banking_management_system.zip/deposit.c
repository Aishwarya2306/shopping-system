#include <stdio.h>
#include "functions.h"
#include "global.h"

void deposit(Account *head) {
    unsigned int acc_no;
    float amount;
    printf("Enter Account Number: ");
    scanf("%u", &acc_no);

    while (head && head->acc_no != acc_no) head = head->next;
    if (!head) {
        printf("Account not found.\n");
        return;
    }

    if (!verify_password(head)) return;

    printf("Enter amount to deposit: ");
    scanf("%f", &amount);

    head->balance += amount;
    add_transaction(head, "deposit", amount);
    printf("Amount deposited successfully!\n");
}
