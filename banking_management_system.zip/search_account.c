#include <stdio.h>
#include "functions.h"

void search_account(Account *head) {
    unsigned int acc_no;
    printf("Enter Account Number to search: ");
    scanf("%u", &acc_no);

    while (head && head->acc_no != acc_no) head = head->next;
    if (!head) {
        printf("Account not found.\n");
        return;
    }

    printf("Account Number: %u\n", head->acc_no);
    printf("Name: %s\n", head->acc_name);
    printf("Contact: %s\n", head->contact);
    printf("Balance: %.2f\n", head->balance);
}
