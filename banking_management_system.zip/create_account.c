#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"
#include "global.h"

void create_account(Account **head) {
    Account *new_acc = (Account *)malloc(sizeof(Account));
    new_acc->next = NULL;

    new_acc->acc_no = next_account_number++;
    printf("Account Number assigned: %u\n", new_acc->acc_no);

    printf("Enter Name: ");
    scanf("%s", new_acc->acc_name);

    printf("Enter Contact: ");
    scanf("%s", new_acc->contact);

    printf("Set Password: ");
    scanf("%s", new_acc->password);

    new_acc->balance = 0.0;
    new_acc->transaction_count = 0;

    new_acc->next = *head;
    *head = new_acc;

    printf("Account created successfully!\n");
}
