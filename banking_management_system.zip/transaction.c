#include <string.h>
#include "functions.h"
#include "global.h"

void add_transaction(Account *acc, const char *type, float amount) {
    int index = acc->transaction_count % 5;
    acc->transactions[index].transaction_id = next_transaction_id++;
    strcpy(acc->transactions[index].type, type);
    acc->transactions[index].amount = amount;
    acc->transaction_count++;
}
