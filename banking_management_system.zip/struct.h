typedef struct Transaction {
    unsigned int transaction_id;
    char type[10];
    float amount;
} Transaction;

typedef struct Account {
    unsigned int acc_no;
    char acc_name[50];
    char contact[15];
    float balance;
    char password[20];
    Transaction transactions[5];
    int transaction_count;
    struct Account *next;
} Account;
