#include <stdio.h>
#include <string.h>
#include "functions.h"

int verify_password(Account *acc) {
    char input[20];
    printf("Enter password for account %u: ", acc->acc_no);
    scanf("%s", input);
    if (strcmp(input, acc->password) == 0)
        return 1;
    else {
        printf("Incorrect password!\n");
        return 0;
    }
}
