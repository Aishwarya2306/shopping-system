#include <stdio.h>
#include "functions.h"

void balance_enquiry(Account *head) {
    unsigned int acc_no;
    printf("Enter Account Number: ");
    scanf("%u", &acc_no);

    while (head && head->acc_no != acc_no) head = head->next;
    if (!head) {
        printf("Account not found.\n");
        return;
    }

    if (!verify_password(head)) return;

    printf("Current Balance: %.2f\n", head->balance);
}
