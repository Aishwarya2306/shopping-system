#include <stdio.h>
#include "functions.h"

void display_accounts(Account *head) {
    while (head) {
        printf("\nAccount Number: %u\n", head->acc_no);
        printf("Name: %s\n", head->acc_name);
        printf("Contact: %s\n", head->contact);
        printf("Balance: %.2f\n", head->balance);
        head = head->next;
    }
}
