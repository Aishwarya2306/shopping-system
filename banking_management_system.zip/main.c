#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

int main() {
    Account *head = NULL;
    char choice;

    load_from_file(&head);

    while (1) {
        printf("\n------ MENU ------\n");
        printf("C: Create account\n");
        printf("D: Deposit amount\n");
        printf("W: Withdraw amount\n");
        printf("T: Transfer money\n");
        printf("B: Balance enquiry\n");
        printf("E: Display all accounts\n");
        printf("F: Search account\n");
        printf("S: Save accounts to file\n");
        printf("Q: Quit\n");
        printf("Enter your choice: ");
        scanf(" %c", &choice);

        switch (choice) {
            case 'C': case 'c': create_account(&head); break;
            case 'D': case 'd': deposit(head); break;
            case 'W': case 'w': withdraw(head); break;
            case 'T': case 't': transfer(head); break;
            case 'B': case 'b': balance_enquiry(head); break;
            case 'E': case 'e': display_accounts(head); break;
            case 'F': case 'f': search_account(head); break;
            case 'S': case 's': save_to_file(head); break;
            case 'Q': case 'q': save_to_file(head); exit(0);
            default: printf("Invalid choice.\n");
        }
    }
    return 0;
}
