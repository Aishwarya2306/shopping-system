unsigned int next_account_number = 1000000000;
unsigned int next_transaction_id = 1;
