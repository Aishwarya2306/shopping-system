#include "struct.h"

void create_account(Account **head);
void deposit(Account *head);
void withdraw(Account *head);
void transfer(Account *head);
void balance_enquiry(Account *head);
void display_accounts(Account *head);
void search_account(Account *head);
int verify_password(Account *acc);
void save_to_file(Account *head);
void load_from_file(Account **head);
void add_transaction(Account *acc, const char *type, float amount);
