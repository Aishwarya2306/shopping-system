#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"
#include "global.h"

void save_to_file(Account *head) {
    FILE *fp = fopen("accounts.dat", "wb");
    if (!fp) {
        printf("Error opening file for writing.\n");
        return;
    }
    fwrite(&next_account_number, sizeof(unsigned int), 1, fp);
    fwrite(&next_transaction_id, sizeof(unsigned int), 1, fp);
    while (head) {
        fwrite(head, sizeof(Account), 1, fp);
        head = head->next;
    }
    fclose(fp);
    printf("Data saved to file.\n");
}

void load_from_file(Account **head) {
    FILE *fp = fopen("accounts.dat", "rb");
    if (!fp) return;

    fread(&next_account_number, sizeof(unsigned int), 1, fp);
    fread(&next_transaction_id, sizeof(unsigned int), 1, fp);
    Account buffer;
    Account *last = NULL;

    while (fread(&buffer, sizeof(Account), 1, fp)) {
        Account *new_acc = (Account *)malloc(sizeof(Account));
        *new_acc = buffer;
        new_acc->next = NULL;
        if (*head == NULL)
            *head = new_acc;
        else
            last->next = new_acc;
        last = new_acc;
    }
    fclose(fp);
}
