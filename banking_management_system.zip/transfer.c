#include <stdio.h>
#include "functions.h"
#include "global.h"

void transfer(Account *head) {
    unsigned int from, to;
    float amount;
    Account *src = NULL, *dest = NULL, *temp = head;

    printf("Enter your Account Number: ");
    scanf("%u", &from);
    printf("Enter recipient Account Number: ");
    scanf("%u", &to);

    while (temp) {
        if (temp->acc_no == from) src = temp;
        if (temp->acc_no == to) dest = temp;
        temp = temp->next;
    }

    if (!src || !dest) {
        printf("One or both accounts not found.\n");
        return;
    }

    if (!verify_password(src)) return;

    printf("Enter amount to transfer: ");
    scanf("%f", &amount);

    if (amount > src->balance) {
        printf("Insufficient balance!\n");
        return;
    }

    src->balance -= amount;
    dest->balance += amount;
    add_transaction(src, "withdraw", amount);
    add_transaction(dest, "deposit", amount);
    printf("Transfer successful!\n");
}
