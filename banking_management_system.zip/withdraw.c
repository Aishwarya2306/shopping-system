#include <stdio.h>
#include "functions.h"
#include "global.h"

void withdraw(Account *head) {
    unsigned int acc_no;
    float amount;
    printf("Enter Account Number: ");
    scanf("%u", &acc_no);

    while (head && head->acc_no != acc_no) head = head->next;
    if (!head) {
        printf("Account not found.\n");
        return;
    }

    if (!verify_password(head)) return;

    printf("Enter amount to withdraw: ");
    scanf("%f", &amount);
    if (amount > head->balance) {
        printf("Insufficient balance!\n");
        return;
    }
    head->balance -= amount;
    add_transaction(head, "withdraw", amount);
    printf("Withdrawal successful!\n");
}
