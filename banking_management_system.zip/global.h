extern unsigned int next_account_number;
extern unsigned int next_transaction_id;
